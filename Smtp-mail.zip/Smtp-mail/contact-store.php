<?php 
session_start();
include("db_connect.php"); 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once '../vendor_msg/autoload.php';
require '../vendor_msg/PHPMailer/src/Exception.php';
require '../vendor_msg/PHPMailer/src/PHPMailer.php';
require '../vendor_msg/PHPMailer/src/SMTP.php';

if (isset($_POST['save_btn'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $msg = $_POST['msg'];

    $mail = new PHPMailer();

    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'st765191@gmail.com';
    $mail->Password = 'crouboqjezobvvec';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('st765191@gmail.com', 'SRB Group');
    $mail->addAddress('hs360863@gmail.com', 'Contact Form'); 
    $mail->Subject = 'Contact Form';
     
    $txt = "Dear {$name},<br><br>";
    $txt .= "Congratulations! You have been Contact Form Submitted Successfully !!<br><br>";
    $txt .= "Email Id: {$email} <br><br>";
    $txt .= "Phone: {$phone} <br><br>";
    $txt .= "Message: {$msg} <br><br>";
    $txt .= "<strong>Best regards,</strong> <br>";
    $txt .= "Our Team";
   
    $html_body = $txt;
    $mail->msgHTML($html_body);

    if ($mail->send()) {
        $sql = "INSERT INTO contact_us (name, email, phone, msg) VALUES ('$name', '$email', '$phone', '$msg')";
        $run_query = mysqli_query($conn, $sql);

        if ($run_query) {
            $_SESSION['status'] = 'success';
        } else {
            $_SESSION['status'] = 'db_error';
        }
    } else {
        $_SESSION['status'] = 'mail_error';
    }

    header("location:../contact-us.php");
    exit(); 
}
?>
